//Define a variable called name with your Name as the assigned value
//Print the value stored in the variable name
//Change the variable to store your father's name
//Print the value stored in the variable name
//Change the variable again to store your mother's name.
//Print the value stored in the variable 
var name ="Sachin Sharma"
console.log(name)
 var name="Heera lal"
console.log(name)
var name="Indra devi"
console.log(name)