//Store the name, school, grade, section, rollno and the marks scored by the student in 3 subjects
//Print the report card of the student (You can make it look nice by using some keyboard symbols )
let name="sachin sharma"
let subject="Maths Science English"
let grades="98 73 93"
console.log(name+"\n"+subject+"\n"+grades)