//Print "Masai School" in the console followed by "A Transformation in Education" in next line
let x="Masai School"
let y="A Transformation in Education"
console.log(x+"\n"+y)